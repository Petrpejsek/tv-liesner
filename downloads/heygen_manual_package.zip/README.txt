HEYGEN MANUAL PACKAGE
============================

Tento balík obsahuje všechny potřebné soubory pro ruční vytvoření videa v HeyGen:

📁 SOUBORY:
- voice_combined.mp3     → Audio track pro HeyGen avatar
- captions.srt          → Titulky/timing pro video
- project_config.json   → Kompletní konfigurace projektu
- voice_config.json     → Nastavení hlasu
- background_info.json  → Doporučení pro background

🎬 KROKY PRO HEYGEN:
1. Přihlas se do HeyGen platformy
2. Vytvoř nový projekt
3. Nahraj voice_combined.mp3 jako audio track
4. Vyber avatar podle avatar_behavior v project_config.json
5. Nastav background podle background_info.json
6. Přidej captions.srt pro timing
7. Vyrenderuj finální video

📄 POZNÁMKY:
- Pipeline byla zastavena po kroku 11
- Všechny AI generované texty a směrnice jsou v project_config.json
- Pro technickou podporu kontaktuj development team

Vytvořeno: 23. 7. 2025 20:29:42
Pipeline ID: pipeline_1753295308888
